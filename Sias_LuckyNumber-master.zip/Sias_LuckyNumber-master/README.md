# Sias_LuckyNumber
简单的抽奖软件
version 1.0
内定数字：1017(一等奖)，3739(三等奖)
